# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
#
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import json
import logging
import os
import uuid
from urllib.parse import unquote_plus

import boto3
from lambda_utils import (
    create_ddb_entry,
    update_job_status,
    extract_username_from_s3_URI,
)

logger = logging.getLogger()
logger.setLevel("INFO")

# S3_BUCKET = os.environ.get("S3_BUCKET")
# SOURCE_PREFIX = os.environ.get("SOURCE_PREFIX")
# DESTINATION_PREFIX = os.environ.get("DESTINATION_PREFIX")
# DYNAMO_TABLE_NAME = os.environ.get("DYNAMO_TABLE_NAME")

from oss_client_utils import (
    get_caller_arn,
    get_oss_client,
    get_oss_http_client,
    get_session,
    get_sts_client,
)

from oss_utils import (
    MODEL_ID_TO_INDEX_REQUEST_MAP,
    create_index_with_retries,
    delete_index_if_present,
    get_access_policy,
    get_host_from_collection_endpoint,
    get_updated_access_policy_with_caller_arn,
    update_access_policy,
)


def lambda_handler(event, context):
    logger.debug("oss-create-index lambda handler called.")
    logger.debug(f"{event=}")
    logger.debug(f"{context=}")

    props = event["ResourceProperties"]
    logger.info("Create new OpenSearch index with props %s" % props)
    region = os.environ["AWS_REGION"]
    # policy_name = props["data_access_policy_name"]
    collection_endpoint = props["collection_endpoint"]
    host = get_host_from_collection_endpoint(collection_endpoint)
    index_name = props["index_name"]
    embedding_model_id = props["embedding_model_id"]
    index_request = MODEL_ID_TO_INDEX_REQUEST_MAP[embedding_model_id]

    session = get_session()
    # sts_client = get_sts_client(session, region)
    # oss_client = get_oss_client(session, region)
    oss_http_client = get_oss_http_client(session, region, host)

    # update_access_policy_with_caller_arn_if_applicable(
    #     sts_client, oss_client, policy_name
    # )

    logger.info("Creating index {}".format(index_name))
    create_index_with_retries(oss_http_client, index_name, index_request)

    return {"PhysicalResourceId": index_name}

    # # Transcribe media to text
    # # Sometimes recording_key is url-encoded, and transcription API wants non-url-encoded
    # # https://stackoverflow.com/questions/44779042/aws-how-to-fix-s3-event-replacing-space-with-sign-in-object-key-names-in-js
    # logger.debug(
    #     f"recording_key from event: {event["Records"][0]["s3"]["object"]["key"]}"
    # )
    # recording_key = unquote_plus(event["Records"][0]["s3"]["object"]["key"])

    # logger.debug(f"decoded recording_key = {recording_key}")
    # _path, filename = os.path.split(recording_key)
    # filename_without_extension, extension = os.path.splitext(filename)
    # media_format = extension[1:].lower()  # Drop the leading "." in extension
    # assert media_format in [
    #     "mp3",
    #     "mp4",
    #     "wav",
    #     "flac",
    #     "ogg",
    #     "amr",
    #     "webm",
    #     "m4a",
    # ], f"Unacceptable media format for transcription: {media_format}"

    # # Generate a random uuid for the job, which will be used
    # # to track this transcript through downstream tasks
    # # (as the partition key in dynamodb)
    # # pattern = r"[^0-9a-zA-Z._-]"
    # # cleaned = re.sub(pattern, "", filename_without_extension)
    # # job_name = "{}_{}".format(cleaned, int(time.time()))
    # job_name = str(uuid.uuid4())
    # logger.debug(f"{job_name=}")

    # media_uri = f"s3://{S3_BUCKET}/{recording_key}"
    # username = extract_username_from_s3_URI(media_uri)
    # logger.debug(f"{media_uri=}")
    # # Use job name (no spaces, etc) as the output file name, because output
    # # has similar regex requirements
    # output_key = "{}/{}/{}.json".format(DESTINATION_PREFIX, username, job_name)
    # logger.debug(f"{output_key=}")
    # # Create item in dynamodb to track media_uri

    # response = create_ddb_entry(
    #     table_name=DYNAMO_TABLE_NAME,
    #     uuid=job_name,
    #     media_uri=media_uri,
    #     username=username,
    # )

    # job_args = {
    #     "TranscriptionJobName": job_name,
    #     "Media": {"MediaFileUri": media_uri},
    #     "MediaFormat": media_format,
    #     "IdentifyLanguage": True,
    #     "OutputBucketName": S3_BUCKET,
    #     "OutputKey": output_key,
    # }
    # logger.debug(f"{job_args=}")
    # try:
    #     response = transcribe_client.start_transcription_job(**job_args)
    #     _job = response["TranscriptionJob"]
    #     logger.info(f"Started transcription job name {job_name}, id {_job}")

    # except Exception as e:
    #     logger.warning(f"ERROR Couldn't start transcription job {job_name}.")
    #     logger.warning(f"Exception: {e}")
    #     raise

    # logger.debug(f"Response to creating dynamodb item {uuid}: {response}")

    # # Update job status in dynamodb
    # update_job_status(
    #     table_name=DYNAMO_TABLE_NAME,
    #     uuid=job_name,
    #     username=username,
    #     new_status="In Progress",
    # )
    # return {
    #     "statusCode": 200,
    #     "body": json.dumps(f"Started transcription job {job_name}"),
    # }
